@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo  ============================================
echo   У Илем - запуск игры
echo  ============================================
echo.

where node >nul 2>&1
if errorlevel 1 (
  echo Не найден Node.js. Установите Node.js LTS и повторите запуск.
  echo https://nodejs.org/
  pause
  exit /b 1
)

if not exist "U_Ilem.html" (
  echo Не найден файл U_Ilem.html. Распакуйте весь комплект в одну папку.
  pause
  exit /b 1
)

if not exist "У Илем.lnk" if exist "CreateShortcut.vbs" (
  cscript //nologo "CreateShortcut.vbs" >nul 2>&1
)

rem Запускаем локальный сервер в отдельном свёрнутом окне.
start "У Илем - локальный сервер" /min cmd /k "node server.js"

echo Запускаю локальный сервер и проверяю готовность...
set READY=0
for /l %%i in (1,1,25) do (
  powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 'http://127.0.0.1:4317/api/health'; if ($r.StatusCode -eq 200) { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
  if not errorlevel 1 (
    set READY=1
    goto OPEN_GAME
  )
  timeout /t 1 >nul
)

:OPEN_GAME
if "%READY%"=="1" (
  echo Сервер готов. Открываю игру...
  start "" "http://127.0.0.1:4317"
  echo.
  echo Если чат сообщает, что Ollama недоступна, запустите приложение Ollama из меню Пуск.
  echo Для завершения игры закройте окно "У Илем - локальный сервер".
) else (
  echo Не удалось запустить локальный сервер. Посмотрите сообщение в окне сервера.
  pause
  exit /b 1
)
endlocal
