'use strict';

// У Илем: локальный сервер и безопасный мост к Ollama.
// Игровое состояние изменяет только браузерный движок после проверки ответа.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { exec } = require('node:child_process');

const HOST = '127.0.0.1';
const PORT = Number(process.env.U_ILEM_PORT || 4173);
const OLLAMA_URL = (process.env.OLLAMA_HOST || 'http://127.0.0.1:11434').replace(/\/$/, '');
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'qwen3:4b';
const ROOT = __dirname;
const MAX_BODY = 1024 * 1024;

const schema = {
  type: 'object',
  properties: {
    reply: { type: 'string' },
    tasks: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          object: { type: 'string' },
          hours: { type: 'number' },
          priority: { type: 'string', enum: ['Срочная', 'Обычная', 'Плановая'] },
          materials: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, qty: { type: 'number' } }, required: ['name', 'qty'] } }
        },
        required: ['title', 'object', 'hours', 'priority', 'materials']
      }
    }
  },
  required: ['reply', 'tasks']
};

function send(res, status, data, headers = {}) {
  const body = JSON.stringify(data);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '', size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('Слишком большой запрос'), { status: 413 })); req.destroy(); return; }
      data += chunk.toString('utf8');
    });
    req.on('end', () => {
      try { resolve(JSON.parse(data || '{}')); }
      catch { reject(Object.assign(new Error('Некорректный JSON'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

async function ollamaTags() {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5000);
  try {
    const response = await fetch(`${OLLAMA_URL}/api/tags`, { signal: controller.signal });
    if (!response.ok) throw new Error(`Ollama HTTP ${response.status}`);
    return await response.json();
  } finally { clearTimeout(timer); }
}

async function handleOllamaStatus(res) {
  try {
    const data = await ollamaTags();
    const models = (data.models || []).map(x => x.name).filter(Boolean);
    const modelReady = models.some(name => name === OLLAMA_MODEL || name.startsWith(`${OLLAMA_MODEL}:`));
    send(res, 200, { available: true, model: OLLAMA_MODEL, modelReady, models, endpoint: OLLAMA_URL });
  } catch (error) {
    send(res, 200, { available: false, model: OLLAMA_MODEL, modelReady: false, models: [], error: error.name === 'AbortError' ? 'Тайм-аут подключения к Ollama' : error.message, endpoint: OLLAMA_URL });
  }
}

async function handleOllamaChat(req, res) {
  const body = await readBody(req);
  const message = String(body.message || '').trim();
  if (!message) return send(res, 400, { error: 'Пустое поручение' });
  if (message.length > 6000) return send(res, 413, { error: 'Поручение слишком длинное (максимум 6000 символов)' });

  const context = body.context && typeof body.context === 'object' ? body.context : {};
  const system = [
    'Ты локальный игровой помощник усадьбы «У Илем». Отвечай только по данным игрового контекста.',
    'Твоя задача: понять поручение, кратко ответить и предложить черновые игровые задачи.',
    'Верни строго JSON по заданной схеме. Не добавляй Markdown и текст вне JSON.',
    'Не утверждай задачи, не списывай ресурсы, не меняй деньги, объекты, календарь или сохранения.',
    'Поле tasks может быть пустым, если поручение требует уточнения.',
    'object указывай только одним из ключей из контекста; если неясно, используй mainHouse.',
    'hours указывай реалистично, от 0.5 до 80. materials только как справочную потребность, ничего не резервируй.',
    'Не выдумывай наличие материалов и навыки. Если данных не хватает, явно укажи это в reply.',
    'Игровые задачи должны быть короткими, конкретными и выполнимыми.'
  ].join(' ');

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 120000);
  try {
    const response = await fetch(`${OLLAMA_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        model: OLLAMA_MODEL,
        stream: false,
        format: schema,
        options: { temperature: 0.25 },
        messages: [
          { role: 'system', content: system },
          { role: 'user', content: `ИГРОВОЙ КОНТЕКСТ:\n${JSON.stringify(context).slice(0, 16000)}\n\nПОРУЧЕНИЕ ИГРОКА:\n${message}` }
        ]
      })
    });
    const raw = await response.text();
    if (!response.ok) return send(res, 502, { error: `Ollama вернула HTTP ${response.status}`, details: raw.slice(0, 1200) });
    let envelope;
    try { envelope = JSON.parse(raw); } catch { return send(res, 502, { error: 'Ollama вернула некорректный ответ' }); }
    let result;
    try {
      let content = String(envelope.message?.content || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
      content = content.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
      result = JSON.parse(content);
    } catch { return send(res, 502, { error: 'Не удалось разобрать структурированный ответ Ollama', raw: String(envelope.message?.content || '').slice(0, 1500) }); }
    if (!result || typeof result.reply !== 'string' || !Array.isArray(result.tasks)) return send(res, 502, { error: 'Ответ Ollama не соответствует игровой схеме' });
    send(res, 200, { ok: true, result: { reply: result.reply.slice(0, 2000), tasks: result.tasks.slice(0, 8) }, model: OLLAMA_MODEL, done: envelope.done === true });
  } catch (error) {
    send(res, 502, { error: error.name === 'AbortError' ? 'Ollama не ответила за 120 секунд' : `Ошибка соединения с Ollama: ${error.message}` });
  } finally { clearTimeout(timer); }
}

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml' };

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${HOST}:${PORT}`);
    if (req.method === 'GET' && url.pathname === '/api/health') return send(res, 200, { ok: true, app: 'У Илем', build: 'U_Ilem_3D_fixed + Ollama Bridge' });
    if (req.method === 'GET' && url.pathname === '/api/ollama/status') return await handleOllamaStatus(res);
    if (req.method === 'POST' && url.pathname === '/api/ollama/chat') return await handleOllamaChat(req, res);
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { error: 'Метод не поддерживается' });

    let pathname = decodeURIComponent(url.pathname === '/' ? '/U_Ilem_3D_fixed.html' : url.pathname);
    const file = path.resolve(ROOT, `.${pathname}`);
    if (!file.startsWith(ROOT + path.sep) && file !== path.join(ROOT, 'U_Ilem_3D_fixed.html')) return send(res, 403, { error: 'Доступ запрещён' });
    fs.stat(file, (err, stat) => {
      if (err || !stat.isFile()) return send(res, 404, { error: 'Файл не найден' });
      res.writeHead(200, { 'Content-Type': mime[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Content-Length': stat.size, 'Cache-Control': 'no-cache' });
      if (req.method === 'HEAD') return res.end();
      fs.createReadStream(file).pipe(res);
    });
  } catch (error) {
    if (!res.headersSent) send(res, error.status || 500, { error: error.message || 'Внутренняя ошибка сервера' });
    else res.destroy();
  }
});

server.listen(PORT, HOST, () => {
  console.log(`У Илем запущен: http://${HOST}:${PORT}`);
  console.log(`Ollama: ${OLLAMA_URL} | модель: ${OLLAMA_MODEL}`);
  if (process.platform === 'win32' && process.env.U_ILEM_NO_BROWSER !== '1') exec(`start "" "http://${HOST}:${PORT}"`);
});

process.on('SIGINT', () => server.close(() => process.exit(0)));
