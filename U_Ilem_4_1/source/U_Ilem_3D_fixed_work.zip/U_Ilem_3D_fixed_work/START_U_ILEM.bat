@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js не найден. Установите Node.js LTS и повторите запуск.
  pause
  exit /b 1
)
set OLLAMA_MODEL=qwen3:4b
node server.js
if errorlevel 1 (
  echo Сервер завершился с ошибкой.
  pause
)
